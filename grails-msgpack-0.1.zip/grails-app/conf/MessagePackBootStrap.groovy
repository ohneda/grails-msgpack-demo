import org.msgpack.rpc.Server
import org.msgpack.rpc.loop.EventLoop
import grails.util.Environment
import org.grails.msgpack.util.ServiceClassExtractor
import org.grails.msgpack.util.ServiceProxyFactory

class MessagePackBootStrap {
    def grailsApplication
    Server svr

    def init = { servletContext ->
        if( Environment.current == Environment.DEVELOPMENT ) {
            100.times{
                def user = new msgpack.User(name: "name${it}", title: "title${it}")
                def role = new msgpack.Role(name: "role-name${it}", title: "role-title${it}")
                user.role = role
                role.user = user
                def message = new msgpack.Message(body: "body${it}",
                        note: "notes${it}",
                        dateCreated: new Date(),
                        dateUpdated: new Date(),
                        postalId: 1234556666,
                        price: 123.55 + it,
                        readCount: it,
                        isPublic: true,
                        owner: user,
                        props: ['p1':'v1', 'p2':'v2'],

                        )
                message.addToComments(new msgpack.Comment(title: "title:${it}-1", body: "body:${it}-1"))
                message.addToComments(new msgpack.Comment(title: "title:${it}-2", body: "body:${it}-2"))
                assert message.save()
                assert message.props
            }
        }
        if(grailsApplication.config.msgpack?.rpc?.expose){
          startMsgpackRpcServer()
        }
    }

    def destroy = {

        if(svr){
          svr.close();
          svr.getEventLoop().shutdown();


        println "SHUTDONW"
        svr.close()
        svr.getEventLoop().getScheduledExecutor().shutdown()
        svr.getEventLoop().shutdown()
        svr.getEventLoop().getScheduledExecutor().awaitTermination(30, java.util.concurrent.TimeUnit.SECONDS )
        println svr.getEventLoop().getScheduledExecutor().isShutdown()
        println svr.getEventLoop().getScheduledExecutor().isTerminated()

        }
    }

    def startMsgpackRpcServer(){

        def extractor = new ServiceClassExtractor(grailsApplication:grailsApplication)
        def targetService = extractor.extract()
        if(targetService){
            ServiceProxyFactory factory = new ServiceProxyFactory(target: targetService)
            factory.registerExcludeMethods(extractor.excludeMethodTemplateServiceClass())
            factory.registerPropertyMethods()
            def proxy = factory.getProxy()
            assert proxy
            proxy.target = grailsApplication.mainContext.getBean(targetService.propertyName)
            EventLoop loop = EventLoop.defaultEventLoop()
            svr = new Server(loop)
            
            svr.serve(proxy)
            svr.listen(grailsApplication.config.msgpack?.rpc?.port ?: 1985)
            log.info("MessagePack RPC server starts.")
        }
    }
}