package org.grails.msgpack

class DummyService {
    static transactional = true
}
